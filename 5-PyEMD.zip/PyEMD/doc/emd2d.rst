EMD2D
=====

Warning
-------

Important This is an experimental module. Please use it with care as no
guarantee can be given for obtaining reasonable results, or that they will be
computed index the most computation optimal way.

Info
----

**EMD** performed on images. This version uses for envelopes 2D splines,
which are span on extrema defined through maximum filter.

Class
-----

.. autoclass:: PyEMD.EMD2D
    :members:
    :special-members:
