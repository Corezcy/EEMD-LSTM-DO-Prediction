Contact
=======

Feel free to send email with any questions, concerns or for whatever reason you feel like.

**Email**
    \\laszuk\\dawid\\@\\gmail.com (remove slashes \\).

**Homepage**
    http://www.laszukdawid.com

**GitHub**
    You can also visit `PyEMD GitHub project <https://www.github.com/laszukdawid/PyEMD>`_ page for this project.

