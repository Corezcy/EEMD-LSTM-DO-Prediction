Visualisation
=============

A simple visualisation helper.

.. autoclass:: PyEMD.Visualisation
    :members:
