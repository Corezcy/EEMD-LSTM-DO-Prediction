
PyEMD's documentation
=====================

Writing documentation is hard. If more clarifications are needed, or you
think others might benefit from extra explanation, don't hesitate to contact
me through contact page.

.. toctree::
   :maxdepth: 2
   :caption: Table of Content

   intro
   usage
   examples
   emd
   eemd
   bemd
   ceemdan
   visualisation
   contact

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
