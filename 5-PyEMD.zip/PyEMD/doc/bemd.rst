BEMD
=====

Warning
-------

Important This is an experimental module. Please use it with care as no
guarantee can be given for obtaining reasonable results, or that they will be
computed index the most computation optimal way.

Info
----

**BEMD** performed on bidimensional data such as images.
This procedure uses morphological operators to detect regional maxima
which are then used to span surface envelope with a radial basis function.

Class
-----

.. autoclass:: PyEMD.BEMD
    :members:
    :special-members:
