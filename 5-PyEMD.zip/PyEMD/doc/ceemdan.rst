CEEMDAN
=======

Info
----

Complete ensembe EMD with adaptive noise (CEEMDAN) performs an EEMD with
the difference that the information about the noise is shared among all workers.

Class
-----

.. autoclass:: PyEMD.CEEMDAN
    :members:
    :special-members:
